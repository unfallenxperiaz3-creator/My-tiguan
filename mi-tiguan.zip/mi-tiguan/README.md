# Mi Tiguan

App Android para el Volkswagen Tiguan R-Line 2023, 2.0 TDI 150 CV (DSG o manual).
Tema en blanco y negro, funciona sin conexión (los vídeos de YouTube sí necesitan internet).
Avisa con una notificación antes de la ITV (30 días, 7 días, 1 día y el mismo día).

## Qué incluye

- **Mi coche**: matrícula, km, fecha de matriculación → calcula la próxima ITV y el próximo cambio de aceite. Se guarda en el móvil.
- **Ficha**: motor, prestaciones, consumo, medidas, capacidades, neumáticos.
- **Ruidos**: qué puede ser un ruido según la zona (suspensión, frenos, motor, cambio…), qué hacer y enlaces a vídeos de YouTube.
- **Revisión**: plan de mantenimiento orientativo y reglas de la ITV.
- **Testigos**: significado de las luces del cuadro.
- **Dónde aparqué**: guarda la posición GPS, te guía de vuelta y avisa 5 minutos antes de que caduque el ticket.
- **Más**: avería o accidente, documentos, funciones ocultas, cuidado y limpieza, reprogramación.

## Compilar el APK en GitHub (sin Android Studio)

1. Crea un repositorio nuevo en GitHub (puede ser privado).
2. Sube **todo el contenido de esta carpeta** a la raíz del repositorio, incluida la carpeta oculta `.github`.
   Desde la terminal de Windows:
   ```
   cd ruta\a\mi-tiguan
   git init
   git add .
   git commit -m "Mi Tiguan"
   git branch -M main
   git remote add origin https://github.com/TU_USUARIO/mi-tiguan.git
   git push -u origin main
   ```
3. En GitHub, abre la pestaña **Actions**. El flujo **Compilar APK** arranca solo al subir (o pulsa *Run workflow*). Tarda 3 – 5 minutos.
4. Cuando termine en verde, entra en la ejecución y descarga **MiTiguan-apk** en la sección *Artifacts*. Es un .zip con `MiTiguan.apk` dentro.
5. Pásalo al teléfono, ábrelo y acepta *Instalar apps de origen desconocido* cuando lo pida.

## Cambiar contenidos

Todo el contenido está en `app/src/main/assets/index.html`. Edítalo, haz commit y push, y GitHub genera un APK nuevo.
Para que el teléfono lo actualice sin desinstalar, sube `versionCode` en `app/build.gradle` (1 → 2 → 3…).

## Nota

Los datos son orientativos (fuentes: km77, fichas oficiales de la gama española 2021 – 2024).
El manual del coche y el plan de mantenimiento de Volkswagen son la referencia final.
