package com.unfallen.mitiguan;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.work.Data;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.util.concurrent.TimeUnit;

/** Avisa 5 minutos antes de que caduque el ticket de aparcamiento. */
public class ParkingWorker extends Worker {

    private static final String CHANNEL = "parking";
    private static final String WORK = "parking-ticket";

    public ParkingWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    static void schedule(Context ctx, int minutes) {
        int delay = Math.max(0, minutes - 5);
        Data data = new Data.Builder().putInt("left", Math.min(5, Math.max(0, minutes))).build();
        OneTimeWorkRequest req = new OneTimeWorkRequest.Builder(ParkingWorker.class)
                .setInitialDelay(delay, TimeUnit.MINUTES)
                .setInputData(data)
                .build();
        WorkManager.getInstance(ctx).enqueueUniqueWork(WORK, ExistingWorkPolicy.REPLACE, req);
    }

    static void cancel(Context ctx) {
        WorkManager.getInstance(ctx).cancelUniqueWork(WORK);
    }

    @NonNull
    @Override
    public Result doWork() {
        Context ctx = getApplicationContext();
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            return Result.success();
        }
        int left = getInputData().getInt("left", 5);
        String text = left > 0
                ? "El ticket de aparcamiento caduca en " + left + " minutos."
                : "El ticket de aparcamiento ha caducado.";

        NotificationManager nm = ctx.getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Ticket de aparcamiento",
                NotificationManager.IMPORTANCE_HIGH));

        Intent open = new Intent(ctx, MainActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(ctx, 1, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification n = new Notification.Builder(ctx, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_car)
                .setContentTitle("Aparcamiento")
                .setContentText(text)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build();
        nm.notify(2, n);
        return Result.success();
    }
}
