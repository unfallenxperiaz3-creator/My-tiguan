package com.unfallen.mitiguan;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;

import androidx.annotation.NonNull;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.concurrent.TimeUnit;

/**
 * Comprueba cada 12 horas cuánto falta para la ITV y avisa con una notificación
 * a 30 días, 7 días, 1 día y el mismo día (una sola vez por cada aviso).
 * WorkManager mantiene la tarea aunque se reinicie el teléfono.
 */
public class ItvWorker extends Worker {

    static final String PREFS = "mitiguan";
    static final String KEY_DATE = "itv_date";
    private static final String CHANNEL = "itv";
    private static final int[] MARKS = {30, 7, 1, 0};

    public ItvWorker(@NonNull Context context, @NonNull WorkerParameters params) {
        super(context, params);
    }

    /** Programa la comprobación periódica; con checkNow=true también comprueba ya. */
    static void schedule(Context ctx, boolean checkNow) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (sp.getString(KEY_DATE, null) == null) return;
        WorkManager wm = WorkManager.getInstance(ctx);
        wm.enqueueUniquePeriodicWork("itv-check", ExistingPeriodicWorkPolicy.KEEP,
                new PeriodicWorkRequest.Builder(ItvWorker.class, 12, TimeUnit.HOURS).build());
        if (checkNow) {
            wm.enqueueUniqueWork("itv-now", ExistingWorkPolicy.REPLACE,
                    new OneTimeWorkRequest.Builder(ItvWorker.class).build());
        }
    }

    @NonNull
    @Override
    public Result doWork() {
        Context ctx = getApplicationContext();
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String iso = sp.getString(KEY_DATE, null);
        if (iso == null) return Result.success();

        LocalDate due;
        try {
            due = LocalDate.parse(iso);
        } catch (Exception e) {
            return Result.success();
        }
        long days = ChronoUnit.DAYS.between(LocalDate.now(), due);

        int hit = -1; // el aviso más cercano que ya toca (30, 7, 1 o 0)
        for (int m : MARKS) {
            if (days <= m) hit = m;
        }
        if (hit < 0) return Result.success();

        String key = "notified_" + iso + "_" + hit;
        if (sp.getBoolean(key, false)) return Result.success();

        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            return Result.success(); // sin permiso: se volverá a intentar en la próxima comprobación
        }

        String date = due.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
        String text;
        if (days > 1) text = "Faltan " + days + " días para la ITV (" + date + "). Pide cita.";
        else if (days == 1) text = "Mañana vence la ITV (" + date + ").";
        else if (days == 0) text = "Hoy vence la ITV.";
        else text = "La ITV venció hace " + (-days) + " días. Pásala cuanto antes.";

        NotificationManager nm = ctx.getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Aviso de ITV",
                NotificationManager.IMPORTANCE_DEFAULT));

        Intent open = new Intent(ctx, MainActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(ctx, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification n = new Notification.Builder(ctx, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_car)
                .setContentTitle("ITV del Tiguan")
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build();
        nm.notify(1, n);
        sp.edit().putBoolean(key, true).apply();
        return Result.success();
    }
}
